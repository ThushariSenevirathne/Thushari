!<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>HOME</title>
</head>
<body>
	<h1 align="center">WELCOME HOME PAGE</h1>

</body>
</html>